# 介入分析方法筆記（報告第 01–05 節底稿）

> 2026-11-18｜對應計畫步驟 1。每節最後的「→ Skill 規則」是之後寫進 SKILL.md 的決策規則。

---

## 01｜要解決什麼問題

**情境**：某個時間點發生了已知事件（政策、法規、新療程、建設），想知道結果變數有沒有因此改變。

**直接比較「介入前平均 vs. 介入後平均」會出錯**，因為：

| 陷阱 | 說明 |
|---|---|
| 原本就有的趨勢 | 序列本來就在下降，介入後平均自然比較低，但這不是介入的效果 |
| 季節性 | 前後兩段涵蓋的月份不同，平均數就會不一樣 |
| 均值回歸 | 常常是數值異常高的時候才推政策，之後回落本來就會發生 |

**中斷時間序列（Interrupted Time Series, ITS）的想法**：用介入**前**的趨勢推估「如果沒有介入會怎樣」，也就是**反事實（counterfactual）**，再拿介入後的實際值跟它比較。

ITS 是準實驗設計，在無法做隨機分派時（例如全國性政策），它是評估介入效果最有力的設計之一。

---

## 02｜核心模型：分段迴歸

$$
Y_t = \beta_0 + \beta_1 T_t + \beta_2 X_t + \beta_3 (T_t - T_0) X_t + \varepsilon_t
$$

| 符號 | 意義 |
|---|---|
| $T_t$ | 時間（1, 2, 3, …） |
| $T_0$ | 介入開始的時間點 |
| $X_t$ | 介入指標：介入前 = 0，介入後 = 1 |
| $(T_t - T_0) X_t$ | 介入後經過的時間（介入前 = 0） |

| 係數 | 解釋 |
|---|---|
| $\beta_0$ | 起始水準 |
| $\beta_1$ | 介入**前**的斜率（原本的趨勢） |
| $\beta_2$ | **水準變化**：介入當下立即跳升或下降多少 |
| $\beta_3$ | **斜率變化**：介入後的趨勢比原本多（少）多少；介入後斜率 = $\beta_1 + \beta_3$ |

- **反事實線**：$\hat Y_t^{cf} = \hat\beta_0 + \hat\beta_1 T_t$，也就是把介入前的趨勢延伸下去
- **介入後第 $k$ 期的效果**：$\beta_2 + \beta_3 k$
- **相對效果**：效果 ÷ 反事實值，政策溝通時常用

> ⚠️ **參數化陷阱**：有些文獻寫成 $\beta_3 T_t X_t$（沒有減 $T_0$）。這種寫法的 $\beta_2$ 變成「外推到 $T=0$ 的水準差」，**不是**介入當下的跳動。
> → **Skill 規則**：一律用 $(T_t - T_0) X_t$，讓 $\beta_2$ 可以直接解釋。

### 結果變數的型態

| 型態 | 模型 |
|---|---|
| 連續（或很大的計數） | 線性分段迴歸；效果是乘法性的時候可以先取 log |
| 計數（死亡數、病例數） | Poisson／quasi-Poisson／負二項 GLM，人口數當 offset；係數解釋成**率比** |
| 比例 | logit 轉換或 binomial GLM |

→ **Skill 規則**：先確認結果變數的型態再選模型。計數資料可以接 glm-analysis 的判斷流程。

---

## 03｜基本假設

| 假設 | 內容 | 怎麼檢查 |
|---|---|---|
| **趨勢延續** | 沒有介入的話，介入前趨勢會持續下去（反事實成立） | 無法直接檢定，只能看介入前段配適得好不好、線性合不合理 |
| **沒有同時發生的事件** | 介入點附近沒有其他會影響結果的事件（歷史威脅） | 靠領域知識追問；可以加共變數，或用控制序列 |
| **介入時間明確** | $T_0$ 清楚；如果是逐步生效，要另外處理 | 追問使用者，必要時設過渡期排除或建模 |
| **測量一致** | 介入前後的定義、測量方式、母體組成沒有改變 | 追問使用者 |
| **足夠的資料點** | 常引用的經驗法則是前後各至少 12 個點（Wagner et al., 2002），月資料至少涵蓋一個完整季節週期 | 數點數 |
| **誤差項** | 獨立、變異數同質；時間序列**通常不獨立** | 見 04 節 |

→ **Skill 規則**：
- 前段或後段少於 12 個點 → 警告，說明檢定力有限；點數極少時建議停止
- 一定要追問「介入前後還有沒有其他事件、定義有沒有改」

---

## 04｜時間序列的陷阱與對策

### 4.1 自相關（最重要）

相鄰時間點的誤差通常**正相關**，這時 OLS 的係數還是不偏，但**標準誤會被低估**，p 值太小，容易誤判「有效果」。

**診斷**

| 工具 | R | 說明 |
|---|---|---|
| 殘差 ACF／PACF 圖 | `acf()`、`pacf()` | 看相關結構，也用來決定 AR 階數 |
| Durbin–Watson | `lmtest::dwtest()` | 只檢定一階自相關 |
| Breusch–Godfrey | `lmtest::bgtest(order = p)` | 可以檢定高階自相關 |
| Ljung–Box | `Box.test(type = "Ljung-Box")` | 綜合檢定多個落後期 |

**對策**

| 方法 | R | 做法 | 定位 |
|---|---|---|---|
| OLS + Newey–West 標準誤 | `sandwich::NeweyWest()` + `lmtest::coeftest()` | 係數不變，只修正標準誤 | 核心：最簡單、穩健 |
| GLS（AR(p) 誤差） | `nlme::gls(correlation = corARMA(p = , q = 0))` | 把自相關直接放進模型，用 AIC 選 p | 核心：主要建議 |
| ARIMA ＋ 介入迴歸項 | `forecast::Arima(xreg = )` | Box–Jenkins 介入模型 | 加分項 |

→ **Skill 規則**：
1. 先配適 OLS，**一定要**做殘差自相關診斷
2. 沒有顯著自相關 → 用 OLS 的結果
3. 有自相關 → 改用 GLS（AR(p)，用 PACF 和 AIC 決定 p），Newey–West 當敏感度分析
4. 報告時並列 OLS 和修正後的標準誤，說明差異

### 4.2 季節性

月資料或週資料常有固定週期，例如交通事故冬季比較高。沒處理的話，季節性會混進殘差，看起來像自相關，也會扭曲效果估計。

| 做法 | R |
|---|---|
| 月份虛擬變數 | `factor(cycle(y))` |
| Fourier 項（正弦／餘弦） | `forecast::fourier(y, K = )` |
| 季節 ARIMA | 加分項 |

→ **Skill 規則**：資料頻率 > 1（月、季、週）時，先畫季節圖並檢查；有季節性就加月份虛擬變數（預設）或 Fourier 項，然後**重新**做自相關診斷。

### 4.3 其他

| 問題 | 處理 |
|---|---|
| 延遲或逐步生效 | 設過渡期，排除那幾個點，或把介入點往後移；兩種做法都要當敏感度分析 |
| 離群值 | 標出來並追問原因，不要自動刪除 |
| 共變數（同時期的其他影響） | 加進模型，例如 Seatbelts 的 `kms`、`PetrolPrice` |
| 非線性趨勢 | 介入前段明顯彎曲時要警告，反事實可能不可信 |

---

## 05｜什麼情境選這個 Skill

| 你的問題 | 用哪個 | 方法 |
|---|---|---|
| **已知事件後，水準或趨勢有沒有改變？** | **本 skill** | ITS、分段迴歸 |
| 一條序列的過去值能不能預測另一條？ | 相關序列分析 | 動態迴歸、VAR |
| 哪些週期最明顯？ | 頻率分析 | 週期圖、頻譜分析 |
| 不知道什麼時候發生斷點，想找出來 | 不在範圍內 | 斷點偵測（`strucchange`） |

**適用條件**（報告的「拿到這樣的資料就能用這個 skill」）：
- 一條依時間排序、間隔相等的序列
- 已知的介入時間點
- 介入前後各有足夠的觀測值（至少 12 個點左右）

---

## 示範資料

| 資料 | 內容 | 介入 | 特徵 | 優先度 |
|---|---|---|---|---|
| `Seatbelts` | 英國每月道路死傷人數，1969/01–1984/12（192 個月） | 安全帶法；`law` 從 **1983/02** 起 = 1 | 介入前 169 點、介入後 23 點；季節性強；有 `kms`、`PetrolPrice` 可當共變數；計數資料 | **必做** |

R 套件都已經裝好：`nlme`、`sandwich`、`lmtest`、`forecast`、`ggplot2`（R 4.4.3）。

---

## 參考文獻

- Wagner, A. K., Soumerai, S. B., Zhang, F., & Ross-Degnan, D. (2002). Segmented regression analysis of interrupted time series studies in medication use research. *Journal of Clinical Pharmacy and Therapeutics, 27*(4), 299–309.
- Bernal, J. L., Cummins, S., & Gasparrini, A. (2017). Interrupted time series regression for the evaluation of public health interventions: a tutorial. *International Journal of Epidemiology, 46*(1), 348–355.
- Harvey, A. C., & Durbin, J. (1986). The effects of seat belt legislation on British road casualties: A case study in structural time series modelling. *Journal of the Royal Statistical Society, Series A, 149*(3), 187–227.
- Hyndman, R. J., & Athanasopoulos, G. (2021). *Forecasting: Principles and Practice* (3rd ed.). OTexts.
